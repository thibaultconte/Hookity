# Hookity Librairie v0.1
## Project for improve commit and branches quality in Git